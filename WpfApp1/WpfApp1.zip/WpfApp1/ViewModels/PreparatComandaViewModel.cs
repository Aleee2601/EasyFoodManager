﻿using EasyFoodManager.Models;

namespace EasyFoodManager.ViewModels
{
    public class PreparatComandaViewModel
    {
        public Preparat Preparat { get; set; }
        public int Cantitate { get; set; } = 1;
    }
}
