﻿namespace EasyFoodManager.Models
{
    public class PreparatMeniuDTO
    {
        public string Tip { get; set; }
        public int Id { get; set; }
        public string Denumire { get; set; }
        public decimal Pret { get; set; }
        public string Cantitate { get; set; }
        public string Categorie { get; set; }
    }

}
