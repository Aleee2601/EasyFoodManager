﻿namespace EasyFoodManager.Models
{
    public class Alergen
    {
        public int Id { get; set; }
        public string Nume { get; set; }
    }
}
