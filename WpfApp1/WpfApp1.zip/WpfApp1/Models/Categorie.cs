﻿namespace EasyFoodManager.Models
{
    public class Categorie
    {
        public int Id { get; set; }
        public string Nume { get; set; }
    }
}
